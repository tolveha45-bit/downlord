# NUTHH TikTok Downloader Bot

Advanced Telegram bot for TikTok video and MP3 downloading.

## Features
- Telegram menu buttons
- TikTok video download
- MP3 extraction
- SQLite user/key/download database
- Admin access-key generation
- Key expiration
- Download limits
- User limits per key
- Auto cleanup
- Docker / Render worker ready

## Setup

1. Install Python 3.11+ and FFmpeg.
2. Copy `.env.example` to `.env`.
3. Put your BotFather token in `BOT_TOKEN`.
4. Put your Telegram numeric ID in `ADMIN_IDS`.
5. Install:
   `pip install -r requirements.txt`
6. Run:
   `python bot.py`

## Admin

Open the bot and send `/admin`.

Create key from the Admin Panel using:
`days downloads max_users`

Example:
`30 100 1`

`0` days = lifetime.
`0` downloads = unlimited.

## Important
Use the bot only for content you are authorized to download. Platform terms and copyright rules may apply.
