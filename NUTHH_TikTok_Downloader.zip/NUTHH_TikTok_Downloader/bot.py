import os
import secrets
import string
import shutil
from datetime import datetime, timedelta, timezone

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup
from telegram.constants import ChatAction
from telegram.ext import (
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
    ContextTypes, filters
)

from config import BOT_TOKEN, ADMIN_IDS, DATABASE_PATH, DOWNLOAD_DIR, MAX_FILE_SIZE_MB, KEY_LENGTH
from database import Database
from downloader import download, valid_tiktok_url

db = Database(DATABASE_PATH)
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

MAIN = ReplyKeyboardMarkup([
    ["🎬 Download Video", "🎵 Download MP3"],
    ["🔑 Activate Key", "📊 My Account"],
    ["ℹ️ Help", "🏠 Main Menu"]
], resize_keyboard=True)

def admin_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔑 Create Key", callback_data="admin_create")],
        [InlineKeyboardButton("📋 Key Info", callback_data="admin_keys")],
        [InlineKeyboardButton("📊 Statistics", callback_data="admin_stats")]
    ])

def is_admin(uid): return uid in ADMIN_IDS

def keygen():
    chars = string.ascii_uppercase + string.digits
    parts = ["".join(secrets.choice(chars) for _ in range(4)) for _ in range(4)]
    return "NUTHH-" + "-".join(parts)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    db.add_user(u.id, u.username)
    await update.message.reply_text(
        "🎬 *NUTHH DOWNLOADER*\n\n"
        "Send a TikTok link and choose Video or MP3.\n\n"
        "🔐 An access key is required.",
        parse_mode="Markdown", reply_markup=MAIN
    )

async def help_cmd(update, context):
    await update.message.reply_text(
        "ℹ️ *Help*\n\n"
        "1. Activate your key.\n"
        "2. Choose 🎬 Video or 🎵 MP3.\n"
        "3. Send a TikTok link.\n"
        "4. Wait for processing.\n\n"
        "Only TikTok URLs are accepted.",
        parse_mode="Markdown", reply_markup=MAIN
    )

async def text_menu(update, context):
    text = update.message.text
    if text == "🏠 Main Menu":
        return await start(update, context)
    if text == "ℹ️ Help":
        return await help_cmd(update, context)
    if text == "🔑 Activate Key":
        context.user_data["state"] = "key"
        return await update.message.reply_text("🔑 Send your access key:", reply_markup=MAIN)
    if text == "📊 My Account":
        s = db.key_status(update.effective_user.id)
        if not s:
            return await update.message.reply_text("🔐 No active key.", reply_markup=MAIN)
        k, exp, max_dl, used, active = s
        remaining = "∞" if max_dl == 0 else max(0, max_dl-used)
        return await update.message.reply_text(
            f"👤 Account\n\n🔑 Key: `{k}`\n📅 Expires: {exp or 'Lifetime'}\n"
            f"📥 Remaining: {remaining}\n🟢 Active: {'Yes' if active else 'No'}",
            parse_mode="Markdown", reply_markup=MAIN)
    if text == "🎬 Download Video":
        context.user_data["state"] = "video"
        return await update.message.reply_text("🎬 Send a TikTok link:", reply_markup=MAIN)
    if text == "🎵 Download MP3":
        context.user_data["state"] = "mp3"
        return await update.message.reply_text("🎵 Send a TikTok link:", reply_markup=MAIN)

    state = context.user_data.get("state")
    if state == "key":
        ok, msg = db.activate_key(update.effective_user.id, text.strip())
        context.user_data["state"] = None
        return await update.message.reply_text(msg, reply_markup=MAIN)

    if state in ("video", "mp3"):
        if not valid_tiktok_url(text.strip()):
            return await update.message.reply_text("❌ Invalid TikTok URL. Please send a valid TikTok link.")
        ok, msg = db.consume_download(update.effective_user.id)
        if not ok:
            return await update.message.reply_text(msg, reply_markup=MAIN)
        return await process_download(update, context, text.strip(), state == "mp3")

    await update.message.reply_text("Please use the menu buttons below 👇", reply_markup=MAIN)

async def process_download(update, context, url, audio):
    uid = update.effective_user.id
    status = await update.message.reply_text("⏳ Processing your download...")
    await update.message.chat.send_action(ChatAction.UPLOAD_AUDIO if audio else ChatAction.UPLOAD_VIDEO)
    path = None
    try:
        path, title = await download(url, DOWNLOAD_DIR, audio)
        size_mb = os.path.getsize(path) / (1024*1024)
        if size_mb > MAX_FILE_SIZE_MB:
            raise RuntimeError(f"File is {size_mb:.1f} MB, above configured Telegram limit.")
        with open(path, "rb") as f:
            if audio:
                await update.message.reply_audio(f, caption=f"🎵 {title}")
            else:
                await update.message.reply_video(f, caption=f"🎬 {title}", supports_streaming=True)
        db.log_download(uid, url, "mp3" if audio else "video", "success")
        await status.edit_text("✅ Download completed!")
    except Exception as e:
        db.log_download(uid, url, "mp3" if audio else "video", "failed")
        await status.edit_text(f"❌ Download failed.\n\n{str(e)[:800]}")
    finally:
        if path and os.path.exists(path):
            try: os.remove(path)
            except OSError: pass

async def admin(update, context):
    if not is_admin(update.effective_user.id):
        return await update.message.reply_text("⛔ Admin only.")
    await update.message.reply_text("👑 Admin Panel", reply_markup=admin_menu())

async def admin_callback(update, context):
    q = update.callback_query
    await q.answer()
    if not is_admin(q.from_user.id):
        return await q.edit_message_text("⛔ Admin only.")
    if q.data == "admin_create":
        context.user_data["state"] = "admin_create"
        return await q.edit_message_text(
            "🔑 Create Key\n\nSend:\n`days downloads max_users`\n\n"
            "Example: `30 100 1`\nUse `0` downloads for unlimited.",
            parse_mode="Markdown")
    if q.data == "admin_stats":
        users, downloads, keys = db.stats()
        return await q.edit_message_text(
            f"📊 Statistics\n\n👥 Users: {users}\n📥 Successful downloads: {downloads}\n🔑 Keys: {keys}")
    if q.data == "admin_keys":
        return await q.edit_message_text("Use /newkey or Create Key to generate keys.")

async def admin_text(update, context):
    if not is_admin(update.effective_user.id): return
    if context.user_data.get("state") != "admin_create": return
    try:
        days, downloads, max_users = map(int, update.message.text.split())
        if days < 0 or downloads < 0 or max_users < 1: raise ValueError
        key = keygen()
        exp = None if days == 0 else (datetime.now(timezone.utc)+timedelta(days=days)).isoformat()
        db.create_key(key, exp, downloads, max_users)
        context.user_data["state"] = None
        await update.message.reply_text(
            f"✅ Key created\n\n🔑 `{key}`\n📅 Expires: {'Lifetime' if not exp else exp}\n"
            f"📥 Downloads: {'Unlimited' if downloads == 0 else downloads}\n👥 Max users: {max_users}",
            parse_mode="Markdown")
    except Exception:
        await update.message.reply_text("❌ Format error. Example: `30 100 1`", parse_mode="Markdown")

def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN is missing in .env")
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("admin", admin))
    app.add_handler(CallbackQueryHandler(admin_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_menu))
    app.add_handler(MessageHandler(filters.TEXT & filters.User(ADMIN_IDS), admin_text))
    print("NUTHH Downloader Bot started.")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
