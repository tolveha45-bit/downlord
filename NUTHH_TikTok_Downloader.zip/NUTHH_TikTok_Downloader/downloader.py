import os
import re
import asyncio
import yt_dlp

URL_RE = re.compile(r"^https?://(www\.)?(tiktok\.com|vm\.tiktok\.com|vt\.tiktok\.com)/", re.I)

def valid_tiktok_url(url: str) -> bool:
    return bool(URL_RE.match(url.strip()))

def _download(url, out_dir, audio=False):
    os.makedirs(out_dir, exist_ok=True)
    template = os.path.join(out_dir, "%(id)s.%(ext)s")
    if audio:
        opts = {
            "format": "bestaudio/best",
            "outtmpl": template,
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192"
            }]
        }
    else:
        opts = {
            "format": "bv*+ba/b",
            "outtmpl": template,
            "merge_output_format": "mp4",
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True
        }
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        path = ydl.prepare_filename(info)
        if audio:
            path = os.path.splitext(path)[0] + ".mp3"
        return path, info.get("title") or "TikTok"

async def download(url, out_dir, audio=False):
    return await asyncio.to_thread(_download, url, out_dir, audio)
